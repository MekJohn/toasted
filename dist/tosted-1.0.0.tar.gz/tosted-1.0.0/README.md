# tosted
Extensive object oriented Toast notifications for Windows.
Include own ready xml document tree visualizer.

(https://learn.microsoft.com/en-us/windows/apps/design/shell/tiles-and-notifications/toast-notifications-overview)

## Installation

```bash
pip install tosted
```

## Usage

```python
import toasted as ts

toast = ts.Reminder("Hey the meeting is near", "see at 10:00")
toast.send()
```


# Acknowledgements

- [winsdk_toast](https://github.com/Mo-Dabao/winsdk_toast)
- [Windows-Toasts](https://github.com/DatGuy1/Windows-Toasts)
- [MarcAlx/notification.py](https://gist.github.com/MarcAlx/443358d5e7167864679ffa1b7d51cd06)
- [GitHub30/win11toast](https://github.com/GitHub30/win11toast)
